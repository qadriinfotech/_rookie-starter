<?php
/**
 *
 * @package rookie Shortcodes functions
 * @since rookie 1.0
 *
 */

/** 
    Tabs
*/
add_shortcode ('tabgroup', function( $atts, $content = null ) {
  extract(shortcode_atts(array(
    'style' => 'horizontal',
    ), $atts));

  $GLOBALS['tab_count'] = 0;
  $i = 1;
  $id = rand();

  do_shortcode( $content );

  if( is_array( $GLOBALS['tabs'] ) ){
    foreach( $GLOBALS['tabs'] as $tab ){  
      $tabs[] = '<li><a href="#panel'.$id.$i.'" data-toggle="tab">' .$tab['title']. '</a></li>';
      $panes[] = '<div class="tab-pane fade" id="panel'.$id.$i.'">' .$tab['content']. '</div>';
      $i++;
    }

    $output = '<div class="tab-container"><ul id="tabs" class="nav nav-tabs" data-tabs="tabs">'.implode( "\n", $tabs ).'</ul><div class="tab-content">'.implode( "\n", $panes ).'</div></div>';
  }

  return $output;
});

add_shortcode ('tab', function( $atts, $content = null) {
  extract(shortcode_atts(array(
    'title' => '',
    ), $atts));
  
  $x = $GLOBALS['tab_count'];
  $GLOBALS['tabs'][$x] = array( 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'content' =>  do_shortcode( $content) );
  $GLOBALS['tab_count']++;
});

/**
    List Shortcodes
*/

add_shortcode ( 'list', function ( $atts, $content = null ) {
  $out = '<ul class="list-arrow unstyled">'. do_shortcode($content) . '</ul>';
    return $out;
});

add_shortcode ( 'list_item', function ( $atts, $content = null ) {
  $out = '<li>' . do_shortcode($content) . '</li>';
    return $out;
});

/**
    
    Cleaning Function

*/

// Enable Shortcodes In Sidebar Widgets
add_filter('widget_text', 'do_shortcode');

// Intelligently remove extra P and BR tags around shortcodes that WordPress likes to add
function rookie_fix_shortcodes($content){   
  $array = array (
    '<p>[' => '[', 
    ']</p>' => ']', 
    ']<br />' => ']',
    ']<br>' => ']'
    );

  $content = strtr($content, $array);
  return $content;
}

add_filter('the_content', 'rookie_fix_shortcodes');

function rookie_cleanup_domdocument($content) {
  $content = preg_replace('#(( ){0,}<br( {0,})(/{0,1})>){1,}$#i', '', $content);
  return $content;
}

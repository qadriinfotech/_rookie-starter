=== Rookie Plugin Template ===
Contributors: Abukwaik
Author link: http://www.croti.com
Tags: wordpress, plugin, template
Requires at least: 3.9
Tested up to: 4.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This is where you craft a short, punchy description of your plugin

== Description ==
This is where you can give a much longer description of your plugin that you can use to explain just how it awesome it really is.

== Installation ==
* The plugin is integrated and required to load with rookie theme. When you activate the theme, you'll see a message in your dashboard asks to install/activate it.

== Frequently Asked Questions ==
= What is the plugin tepmlate for? =
This plugin template is designed to help you get started with any new WordPress plugin.

== Changelog ==
= 1.0 =
* 2015-01-01
* Initial release

== Upgrade Notice ==
= 1.0 =
* 2015-01-01
* Initial release